-- ─────────────────────────────────────────────────────────────────────────────
--  SPiN Studio — Supabase Schema
--  Run this in: Supabase Dashboard → SQL Editor → New Query
-- ─────────────────────────────────────────────────────────────────────────────

-- Enable UUID extension (already enabled by default in Supabase)
create extension if not exists "uuid-ossp";

-- ── Bookings table ──────────────────────────────────────────────────────────

create table if not exists public.bookings (
  id                  uuid          primary key default uuid_generate_v4(),
  service             text          not null check (service in ('photography', 'video', 'podcast', 'content')),
  date                date          not null,
  time                time          not null,
  name                text          not null,
  phone               text          not null default '',
  email               text          not null default '',
  notes               text,
  telegram_user_id    bigint,
  telegram_username   text,
  status              text          not null default 'pending'
                                    check (status in ('pending', 'confirmed', 'cancelled')),
  created_at          timestamptz   not null default now()
);

-- ── Row-Level Security ──────────────────────────────────────────────────────
-- Allow anonymous inserts (Mini App users are not authenticated)
-- Only your backend/admin can read all rows

alter table public.bookings enable row level security;

-- Allow INSERT from anyone (the Mini App)
create policy "Allow anonymous insert"
  on public.bookings
  for insert
  to anon
  with check (true);

-- Allow SELECT only for the user's own booking (by Telegram user ID)
create policy "Allow user to read own bookings"
  on public.bookings
  for select
  to anon
  using (
    telegram_user_id = (current_setting('request.jwt.claims', true)::json->>'sub')::bigint
  );

-- (Admin/service role can read everything — no policy needed for service_role)

-- ── Index for slot queries ──────────────────────────────────────────────────

create index if not exists idx_bookings_date_service
  on public.bookings (date, service);

-- ── Done ────────────────────────────────────────────────────────────────────
-- ✅ Table created
-- ✅ RLS enabled
-- ✅ Anonymous inserts allowed
-- ✅ Index on date + service for fast slot lookups
