import type { Service, TimeSlot } from '../types'

// ─── Service Catalogue ──────────────────────────────────────────────────────

export const SERVICES: Service[] = [
  {
    id:          'photography',
    title:       'Photo Session',
    subtitle:    'Brand · Portrait · Product',
    duration:    'from 2h',
    price:       'from $150',
    icon:        '📷',
    description: 'Professional studio photography with full post-production. Perfect for brands, headshots, and product shots.',
  },
  {
    id:          'video',
    title:       'Video Production',
    subtitle:    'Reels · Ads · Corporate',
    duration:    'from 4h',
    price:       'from $400',
    icon:        '🎬',
    description: 'Full-service video production from scripting to final edit. Ideal for social ads, corporate videos, and reels.',
  },
  {
    id:          'podcast',
    title:       'Podcast Studio',
    subtitle:    'Audio · Video · Streaming',
    duration:    'from 1h',
    price:       'from $80',
    icon:        '🎙️',
    description: 'Acoustically treated studio with pro-grade mics, lighting, and multi-camera setups ready to stream.',
  },
  {
    id:          'content',
    title:       'Content Day',
    subtitle:    'Social · UGC · Stories',
    duration:    'full day',
    price:       'from $600',
    icon:        '✨',
    description: 'A dedicated content creation day — everything you need for a month of social media content in one session.',
  },
]

// ─── Time Slots ─────────────────────────────────────────────────────────────

export const ALL_TIME_SLOTS: TimeSlot[] = [
  { value: '09:00', label: '9:00 AM',  available: true },
  { value: '10:00', label: '10:00 AM', available: true },
  { value: '11:00', label: '11:00 AM', available: true },
  { value: '12:00', label: '12:00 PM', available: true },
  { value: '13:00', label: '1:00 PM',  available: true },
  { value: '14:00', label: '2:00 PM',  available: true },
  { value: '15:00', label: '3:00 PM',  available: true },
  { value: '16:00', label: '4:00 PM',  available: true },
  { value: '17:00', label: '5:00 PM',  available: true },
  { value: '18:00', label: '6:00 PM',  available: true },
]

/** Returns today's date as "YYYY-MM-DD" */
export function todayISO(): string {
  return new Date().toISOString().split('T')[0]
}

/** Returns the minimum bookable date (today) and max (3 months out) */
export function dateRange() {
  const min = new Date()
  const max = new Date()
  max.setMonth(max.getMonth() + 3)
  return {
    min: min.toISOString().split('T')[0],
    max: max.toISOString().split('T')[0],
  }
}
