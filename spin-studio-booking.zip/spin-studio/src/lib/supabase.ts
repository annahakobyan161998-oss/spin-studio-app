import { createClient } from '@supabase/supabase-js'
import type { BookingRow } from '../types'

// ─── Supabase Client ────────────────────────────────────────────────────────

const supabaseUrl  = import.meta.env.VITE_SUPABASE_URL  as string
const supabaseKey  = import.meta.env.VITE_SUPABASE_ANON_KEY as string

if (!supabaseUrl || !supabaseKey) {
  throw new Error(
    '[SPiN Studio] Missing Supabase env vars.\n' +
    'Set VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY in your .env file.'
  )
}

export const supabase = createClient(supabaseUrl, supabaseKey)

// ─── Database Helpers ───────────────────────────────────────────────────────

/**
 * Insert a new booking into the `bookings` table.
 * Returns the inserted row or throws on error.
 */
export async function createBooking(
  payload: Omit<BookingRow, 'id' | 'status' | 'created_at'>
): Promise<BookingRow> {
  const { data, error } = await supabase
    .from('bookings')
    .insert({
      ...payload,
      status: 'pending',
    })
    .select()
    .single()

  if (error) {
    console.error('[Supabase] Insert error:', error)
    throw new Error(error.message)
  }

  return data as BookingRow
}

/**
 * Fetch already-booked time slots for a given date and service.
 * Used to disable unavailable slots in the date picker.
 */
export async function getBookedSlots(
  date: string,
  service: string
): Promise<string[]> {
  const { data, error } = await supabase
    .from('bookings')
    .select('time')
    .eq('date', date)
    .eq('service', service)
    .neq('status', 'cancelled')

  if (error) {
    console.error('[Supabase] Fetch slots error:', error)
    return []
  }

  return (data ?? []).map((row: { time: string }) => row.time)
}
