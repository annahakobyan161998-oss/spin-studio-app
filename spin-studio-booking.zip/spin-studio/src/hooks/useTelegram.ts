import { useEffect, useMemo } from 'react'
import type { TelegramUser } from '../types'

// ─── useTelegram ────────────────────────────────────────────────────────────

/**
 * Hook that wraps the Telegram WebApp SDK.
 * Safely degrades when running outside of Telegram (e.g. in a browser).
 */
export function useTelegram() {
  const tg = useMemo(() => window.Telegram?.WebApp, [])

  useEffect(() => {
    if (!tg) return
    tg.ready()
    tg.expand()
  }, [tg])

  const user: TelegramUser | null = tg?.initDataUnsafe?.user ?? null

  /** Trigger a light haptic tap (e.g. on button press) */
  const hapticLight = () => tg?.hapticFeedback.impactOccurred('light')

  /** Trigger a success notification haptic */
  const hapticSuccess = () => tg?.hapticFeedback.notificationOccurred('success')

  /** Trigger an error notification haptic */
  const hapticError = () => tg?.hapticFeedback.notificationOccurred('error')

  /** Show the Telegram native Back Button */
  const showBackButton = (onBack: () => void) => {
    if (!tg) return
    tg.BackButton.show()
    tg.BackButton.onClick(onBack)
    return () => tg.BackButton.offClick(onBack)
  }

  /** Hide the Telegram native Back Button */
  const hideBackButton = () => tg?.BackButton.hide()

  return {
    tg,
    user,
    hapticLight,
    hapticSuccess,
    hapticError,
    showBackButton,
    hideBackButton,
    isInsideTelegram: !!tg,
  }
}
