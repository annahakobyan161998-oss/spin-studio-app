import type { Step, StepMeta } from '../types'

const STEPS: StepMeta[] = [
  { number: 1, label: 'Service'  },
  { number: 2, label: 'Schedule' },
  { number: 3, label: 'Details'  },
  { number: 4, label: 'Confirm'  },
]

interface Props {
  current: Step
}

export function StepIndicator({ current }: Props) {
  return (
    <div className="flex items-center justify-center gap-0 px-4">
      {STEPS.map((step, i) => {
        const isDone   = step.number < current
        const isActive = step.number === current

        return (
          <div key={step.number} className="flex items-center">
            {/* Step circle */}
            <div className="flex flex-col items-center gap-1">
              <div
                className={[
                  'w-8 h-8 rounded-full flex items-center justify-center text-xs font-mono font-medium transition-all duration-300',
                  isDone   ? 'bg-spin-gold text-spin-black'  : '',
                  isActive ? 'bg-spin-gold text-spin-black ring-2 ring-spin-gold ring-offset-2 ring-offset-spin-black animate-pulse-gold' : '',
                  !isDone && !isActive ? 'bg-spin-border text-spin-silver' : '',
                ].join(' ')}
              >
                {isDone ? (
                  <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                    <path d="M2 7l3.5 3.5L12 3.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                ) : (
                  step.number
                )}
              </div>
              <span
                className={[
                  'text-[10px] font-body tracking-wider uppercase transition-colors duration-300',
                  isActive ? 'text-spin-gold' : 'text-spin-silver opacity-60',
                ].join(' ')}
              >
                {step.label}
              </span>
            </div>

            {/* Connector line (not after last) */}
            {i < STEPS.length - 1 && (
              <div
                className={[
                  'h-px w-8 mx-1 mb-4 transition-all duration-500',
                  step.number < current ? 'bg-spin-gold' : 'bg-spin-border',
                ].join(' ')}
              />
            )}
          </div>
        )
      })}
    </div>
  )
}
