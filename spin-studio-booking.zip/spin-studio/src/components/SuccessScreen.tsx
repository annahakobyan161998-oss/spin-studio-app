import { useEffect } from 'react'
import { useTelegram } from '../hooks/useTelegram'
import type { BookingFormData } from '../types'
import { SERVICES } from '../lib/services'

interface Props {
  booking: BookingFormData
  bookingId: string
}

export function SuccessScreen({ booking, bookingId }: Props) {
  const { tg, hapticSuccess } = useTelegram()

  const service = SERVICES.find(s => s.id === booking.service)

  useEffect(() => {
    hapticSuccess()

    // Auto-close Mini App after 4s if inside Telegram
    const timer = setTimeout(() => {
      tg?.close()
    }, 4000)

    return () => clearTimeout(timer)
  }, []) // eslint-disable-line react-hooks/exhaustive-deps

  const dateFormatted = booking.date
    ? new Date(booking.date + 'T00:00:00').toLocaleDateString('en-US', {
        weekday: 'long', month: 'long', day: 'numeric',
      })
    : '—'

  return (
    <div className="flex flex-col items-center justify-center min-h-[70vh] px-6 text-center animate-fade-up">
      {/* Animated checkmark ring */}
      <div className="relative mb-8">
        <div className="w-24 h-24 rounded-full border-2 border-spin-gold flex items-center justify-center animate-pulse-gold">
          <svg width="40" height="40" viewBox="0 0 40 40" fill="none">
            <path
              d="M8 20l8 8L32 12"
              stroke="#C9A84C"
              strokeWidth="3"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="animate-fade-in"
            />
          </svg>
        </div>
        {/* Orbit ring */}
        <div
          className="absolute inset-0 rounded-full border border-spin-gold/20 animate-spin"
          style={{ animationDuration: '8s' }}
        />
      </div>

      <h2 className="font-display text-4xl text-spin-gold tracking-widest mb-2">
        BOOKED!
      </h2>
      <p className="text-spin-silver text-sm font-body mb-8">
        Your session is confirmed. We'll reach out to you shortly.
      </p>

      {/* Summary card */}
      <div className="w-full max-w-xs bg-spin-card border border-spin-border rounded-2xl p-5 text-left space-y-3">
        <div className="flex items-center gap-2 border-b border-spin-border pb-3 mb-3">
          <span className="text-xl">{service?.icon}</span>
          <div>
            <p className="font-display text-lg text-spin-white tracking-wide">{service?.title}</p>
            <p className="text-spin-silver text-xs font-mono">{service?.subtitle}</p>
          </div>
        </div>

        <SummaryRow icon="📅" label="Date"    value={dateFormatted} />
        <SummaryRow icon="⏰" label="Time"    value={booking.time} />
        <SummaryRow icon="👤" label="Name"    value={booking.name} />
        <SummaryRow icon="📞" label="Contact" value={booking.phone || booking.email} />

        <div className="border-t border-spin-border pt-3 mt-3">
          <p className="text-spin-silver/60 text-[10px] font-mono tracking-widest uppercase">
            Booking ID
          </p>
          <p className="text-spin-gold text-xs font-mono mt-0.5">
            #{bookingId.slice(0, 8).toUpperCase()}
          </p>
        </div>
      </div>

      <p className="text-spin-silver/50 text-xs font-mono mt-8 tracking-wider">
        This window will close automatically…
      </p>
    </div>
  )
}

function SummaryRow({ icon, label, value }: { icon: string; label: string; value: string }) {
  return (
    <div className="flex items-center gap-3">
      <span className="text-base w-5 text-center">{icon}</span>
      <div>
        <p className="text-spin-silver/50 text-[10px] font-mono tracking-wider uppercase">{label}</p>
        <p className="text-spin-white text-sm font-body">{value}</p>
      </div>
    </div>
  )
}
