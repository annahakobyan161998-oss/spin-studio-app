import { useState, useEffect, useCallback } from 'react'
import { useTelegram } from '../hooks/useTelegram'
import { createBooking, getBookedSlots } from '../lib/supabase'
import { SERVICES, ALL_TIME_SLOTS, dateRange } from '../lib/services'
import { ServiceCard } from './ServiceCard'
import { StepIndicator } from './StepIndicator'
import { LoadingSpinner } from './LoadingSpinner'
import { SuccessScreen } from './SuccessScreen'
import type { BookingFormData, Step, TimeSlot } from '../types'
import toast from 'react-hot-toast'

const INITIAL_FORM: BookingFormData = {
  service: null,
  date:    '',
  time:    '',
  name:    '',
  phone:   '',
  email:   '',
  notes:   '',
}

export function BookingForm() {
  const { user, hapticLight, hapticError, showBackButton, hideBackButton } = useTelegram()

  const [step, setStep]           = useState<Step>(1)
  const [form, setForm]           = useState<BookingFormData>(INITIAL_FORM)
  const [slots, setSlots]         = useState<TimeSlot[]>(ALL_TIME_SLOTS)
  const [loadingSlots, setLoadingSlots] = useState(false)
  const [submitting, setSubmitting]     = useState(false)
  const [bookingId, setBookingId]       = useState<string | null>(null)

  const { min: minDate, max: maxDate } = dateRange()

  // ── Telegram back button ────────────────────────────────────────────────

  const goBack = useCallback(() => {
    if (step > 1) {
      hapticLight()
      setStep(s => (s - 1) as Step)
    }
  }, [step, hapticLight])

  useEffect(() => {
    if (step > 1) {
      showBackButton(goBack)
    } else {
      hideBackButton()
    }
  }, [step, goBack]) // eslint-disable-line react-hooks/exhaustive-deps

  // ── Load booked slots when date/service changes ─────────────────────────

  useEffect(() => {
    if (!form.date || !form.service) return
    setLoadingSlots(true)
    getBookedSlots(form.date, form.service).then(booked => {
      setSlots(
        ALL_TIME_SLOTS.map(slot => ({
          ...slot,
          available: !booked.includes(slot.value),
        }))
      )
      setLoadingSlots(false)
    })
  }, [form.date, form.service])

  // ── Step validation ─────────────────────────────────────────────────────

  const canProceed: Record<Step, boolean> = {
    1: !!form.service,
    2: !!form.date && !!form.time,
    3: !!form.name.trim() && !!(form.phone.trim() || form.email.trim()),
    4: true,
  }

  const next = () => {
    if (!canProceed[step]) {
      hapticError()
      toast.error(getValidationMessage(step))
      return
    }
    hapticLight()
    setStep(s => (s + 1) as Step)
  }

  // ── Submit ──────────────────────────────────────────────────────────────

  const submit = async () => {
    setSubmitting(true)
    try {
      const row = await createBooking({
        service:            form.service!,
        date:               form.date,
        time:               form.time,
        name:               form.name.trim(),
        phone:              form.phone.trim(),
        email:              form.email.trim(),
        notes:              form.notes.trim(),
        telegram_user_id:   user?.id   ?? null,
        telegram_username:  user?.username ?? null,
      })
      setBookingId(row.id)
    } catch (err) {
      hapticError()
      toast.error('Could not save your booking. Please try again.')
      console.error(err)
    } finally {
      setSubmitting(false)
    }
  }

  // ── Success screen ──────────────────────────────────────────────────────

  if (bookingId) {
    return <SuccessScreen booking={form} bookingId={bookingId} />
  }

  // ── Render ──────────────────────────────────────────────────────────────

  const selectedService = SERVICES.find(s => s.id === form.service)

  return (
    <div className="flex flex-col min-h-screen bg-spin-black">

      {/* ── Header ─────────────────────────────────────────────────── */}
      <header className="sticky top-0 z-20 bg-spin-black/90 backdrop-blur-md border-b border-spin-border px-4 pt-4 pb-5">
        <div className="flex items-baseline justify-between mb-4">
          <div>
            <h1 className="font-display text-3xl text-spin-gold tracking-widest">SPiN STUDIO</h1>
            <p className="text-spin-silver text-xs font-mono tracking-wider -mt-0.5">BOOK A SESSION</p>
          </div>
          {user && (
            <span className="text-spin-silver text-xs font-body">
              Hi, {user.first_name} 👋
            </span>
          )}
        </div>
        <StepIndicator current={step} />
      </header>

      {/* ── Step Content ────────────────────────────────────────────── */}
      <main className="flex-1 overflow-y-auto px-4 py-6 space-y-4">

        {/* Step 1 — Choose Service */}
        {step === 1 && (
          <div className="animate-fade-up space-y-3">
            <SectionHeader title="What are you booking?" subtitle="Choose a service to continue" />
            {SERVICES.map(service => (
              <ServiceCard
                key={service.id}
                service={service}
                selected={form.service === service.id}
                onSelect={id => {
                  hapticLight()
                  setForm(f => ({ ...f, service: id, time: '' }))
                }}
              />
            ))}
          </div>
        )}

        {/* Step 2 — Date & Time */}
        {step === 2 && (
          <div className="animate-fade-up space-y-5">
            <SectionHeader title="Pick a date & time" subtitle={`Booking for: ${selectedService?.title}`} />

            {/* Date picker */}
            <div>
              <Label>Date</Label>
              <input
                type="date"
                min={minDate}
                max={maxDate}
                value={form.date}
                onChange={e => {
                  hapticLight()
                  setForm(f => ({ ...f, date: e.target.value, time: '' }))
                }}
                className="w-full bg-spin-card border border-spin-border rounded-xl px-4 py-3 text-spin-white font-mono text-sm focus:outline-none focus:border-spin-gold transition-colors"
              />
            </div>

            {/* Time slots */}
            {form.date && (
              <div>
                <Label>Available time slots</Label>
                {loadingSlots ? (
                  <div className="flex justify-center py-8">
                    <LoadingSpinner size="sm" label="Checking availability…" />
                  </div>
                ) : (
                  <div className="grid grid-cols-3 gap-2">
                    {slots.map(slot => (
                      <button
                        key={slot.value}
                        type="button"
                        disabled={!slot.available}
                        onClick={() => {
                          if (!slot.available) return
                          hapticLight()
                          setForm(f => ({ ...f, time: slot.value }))
                        }}
                        className={[
                          'py-2.5 rounded-lg text-sm font-mono border transition-all duration-150',
                          !slot.available
                            ? 'opacity-30 cursor-not-allowed border-spin-border text-spin-silver line-through'
                            : form.time === slot.value
                              ? 'bg-spin-gold border-spin-gold text-spin-black font-medium'
                              : 'border-spin-border text-spin-silver hover:border-spin-gold/50 hover:text-spin-white',
                        ].join(' ')}
                      >
                        {slot.label}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* Step 3 — Contact Details */}
        {step === 3 && (
          <div className="animate-fade-up space-y-4">
            <SectionHeader title="Your details" subtitle="We'll use this to confirm your booking" />

            <div>
              <Label>Full Name *</Label>
              <TextInput
                placeholder="e.g. Alex Johnson"
                value={form.name}
                onChange={v => setForm(f => ({ ...f, name: v }))}
              />
            </div>

            <div>
              <Label>Phone Number *</Label>
              <TextInput
                placeholder="+1 (555) 000-0000"
                type="tel"
                value={form.phone}
                onChange={v => setForm(f => ({ ...f, phone: v }))}
              />
            </div>

            <div>
              <Label>Email Address</Label>
              <TextInput
                placeholder="you@example.com"
                type="email"
                value={form.email}
                onChange={v => setForm(f => ({ ...f, email: v }))}
              />
            </div>

            <div>
              <Label>Notes / Special Requests</Label>
              <textarea
                rows={3}
                placeholder="Anything we should know beforehand?"
                value={form.notes}
                onChange={e => setForm(f => ({ ...f, notes: e.target.value }))}
                className="w-full bg-spin-card border border-spin-border rounded-xl px-4 py-3 text-spin-white font-body text-sm placeholder:text-spin-silver/40 focus:outline-none focus:border-spin-gold transition-colors resize-none"
              />
            </div>
          </div>
        )}

        {/* Step 4 — Review & Confirm */}
        {step === 4 && (
          <div className="animate-fade-up space-y-4">
            <SectionHeader title="Review your booking" subtitle="Everything look right?" />

            <div className="bg-spin-card border border-spin-border rounded-2xl divide-y divide-spin-border overflow-hidden">
              <ReviewRow label="Service" value={`${selectedService?.icon} ${selectedService?.title}`} />
              <ReviewRow
                label="Date"
                value={new Date(form.date + 'T00:00:00').toLocaleDateString('en-US', {
                  weekday: 'long', month: 'long', day: 'numeric',
                })}
              />
              <ReviewRow label="Time" value={form.time} />
              <ReviewRow label="Name" value={form.name} />
              {form.phone && <ReviewRow label="Phone" value={form.phone} />}
              {form.email && <ReviewRow label="Email" value={form.email} />}
              {form.notes && <ReviewRow label="Notes" value={form.notes} />}
            </div>

            <p className="text-spin-silver/60 text-xs font-mono text-center leading-relaxed">
              By confirming, you agree to our cancellation policy.<br/>
              We'll contact you within 24h to finalize details.
            </p>

            <button
              type="button"
              onClick={submit}
              disabled={submitting}
              className="w-full py-4 rounded-xl bg-spin-gold text-spin-black font-display text-xl tracking-widest transition-all duration-200 hover:bg-spin-gold-light active:scale-[0.98] disabled:opacity-60 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              {submitting ? (
                <LoadingSpinner size="sm" />
              ) : (
                'CONFIRM BOOKING'
              )}
            </button>
          </div>
        )}
      </main>

      {/* ── Footer CTA (steps 1–3) ──────────────────────────────────── */}
      {step < 4 && (
        <footer className="sticky bottom-0 bg-spin-black/90 backdrop-blur-md border-t border-spin-border px-4 py-4">
          <button
            type="button"
            onClick={next}
            className={[
              'w-full py-4 rounded-xl font-display text-xl tracking-widest transition-all duration-200',
              canProceed[step]
                ? 'bg-spin-gold text-spin-black hover:bg-spin-gold-light active:scale-[0.98]'
                : 'bg-spin-border text-spin-silver cursor-not-allowed',
            ].join(' ')}
          >
            {step === 3 ? 'REVIEW BOOKING →' : 'NEXT →'}
          </button>
        </footer>
      )}
    </div>
  )
}

// ── Small sub-components ────────────────────────────────────────────────────

function SectionHeader({ title, subtitle }: { title: string; subtitle?: string }) {
  return (
    <div className="mb-2">
      <h2 className="font-display text-2xl text-spin-white tracking-wide">{title}</h2>
      {subtitle && <p className="text-spin-silver text-xs font-mono mt-0.5">{subtitle}</p>}
    </div>
  )
}

function Label({ children }: { children: React.ReactNode }) {
  return (
    <p className="text-spin-silver text-xs font-mono tracking-wider uppercase mb-1.5">
      {children}
    </p>
  )
}

function TextInput({
  placeholder, value, onChange, type = 'text',
}: {
  placeholder: string; value: string; onChange: (v: string) => void; type?: string
}) {
  return (
    <input
      type={type}
      placeholder={placeholder}
      value={value}
      onChange={e => onChange(e.target.value)}
      className="w-full bg-spin-card border border-spin-border rounded-xl px-4 py-3 text-spin-white font-body text-sm placeholder:text-spin-silver/40 focus:outline-none focus:border-spin-gold transition-colors"
    />
  )
}

function ReviewRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-start gap-3 px-5 py-3.5">
      <span className="text-spin-silver/60 text-xs font-mono tracking-wider uppercase w-16 shrink-0 mt-0.5">
        {label}
      </span>
      <span className="text-spin-white text-sm font-body leading-snug">{value}</span>
    </div>
  )
}

function getValidationMessage(step: Step): string {
  switch (step) {
    case 1: return 'Please select a service first'
    case 2: return 'Please choose a date and time slot'
    case 3: return 'Name and phone (or email) are required'
    default: return 'Please complete all fields'
  }
}
