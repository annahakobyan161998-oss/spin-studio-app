import type { Service, ServiceId } from '../types'

interface Props {
  service:   Service
  selected:  boolean
  onSelect:  (id: ServiceId) => void
}

export function ServiceCard({ service, selected, onSelect }: Props) {
  return (
    <button
      type="button"
      onClick={() => onSelect(service.id)}
      className={[
        'w-full text-left p-4 rounded-xl border transition-all duration-200 group relative overflow-hidden',
        selected
          ? 'border-spin-gold bg-spin-gold/10'
          : 'border-spin-border bg-spin-card hover:border-spin-gold/40 hover:bg-spin-card/80',
      ].join(' ')}
    >
      {/* Gold accent bar */}
      <div
        className={[
          'absolute left-0 top-0 bottom-0 w-0.5 transition-all duration-300',
          selected ? 'bg-spin-gold' : 'bg-transparent group-hover:bg-spin-gold/30',
        ].join(' ')}
      />

      <div className="flex items-start gap-3 pl-1">
        {/* Icon */}
        <span className="text-2xl mt-0.5 leading-none">{service.icon}</span>

        {/* Text */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between gap-2">
            <h3 className={[
              'font-display text-xl tracking-wide leading-tight transition-colors',
              selected ? 'text-spin-gold' : 'text-spin-white group-hover:text-spin-gold-light',
            ].join(' ')}>
              {service.title}
            </h3>
            <span className={[
              'text-xs font-mono px-2 py-0.5 rounded-full border shrink-0 transition-colors',
              selected
                ? 'text-spin-gold border-spin-gold bg-spin-gold/10'
                : 'text-spin-silver border-spin-border',
            ].join(' ')}>
              {service.price}
            </span>
          </div>

          <p className="text-spin-silver text-xs font-mono tracking-wider mt-0.5">
            {service.subtitle}
          </p>

          <p className={[
            'text-xs mt-2 leading-relaxed transition-colors',
            selected ? 'text-spin-white/80' : 'text-spin-silver/70',
          ].join(' ')}>
            {service.description}
          </p>

          <div className="flex items-center gap-1 mt-2">
            <svg width="12" height="12" viewBox="0 0 12 12" fill="none" className="text-spin-silver">
              <circle cx="6" cy="6" r="5" stroke="currentColor" strokeWidth="1.2"/>
              <path d="M6 3.5v2.5l1.5 1.5" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round"/>
            </svg>
            <span className="text-spin-silver text-[11px] font-mono">{service.duration}</span>
          </div>
        </div>
      </div>

      {/* Selected check */}
      {selected && (
        <div className="absolute top-3 right-3">
          <div className="w-5 h-5 rounded-full bg-spin-gold flex items-center justify-center">
            <svg width="10" height="10" viewBox="0 0 10 10" fill="none">
              <path d="M2 5l2.5 2.5L8 3" stroke="#0A0A0A" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </div>
        </div>
      )}
    </button>
  )
}
