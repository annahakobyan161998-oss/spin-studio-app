// ─── Booking Domain ────────────────────────────────────────────────────────

export type ServiceId =
  | 'photography'
  | 'video'
  | 'podcast'
  | 'content';

export interface Service {
  id:          ServiceId;
  title:       string;
  subtitle:    string;
  duration:    string;   // e.g. "from 2h"
  price:       string;   // e.g. "from $150"
  icon:        string;   // emoji or lucide icon name
  description: string;
}

export interface TimeSlot {
  value: string;   // "10:00"
  label: string;   // "10:00 AM"
  available: boolean;
}

export interface BookingFormData {
  service:  ServiceId | null;
  date:     string;          // ISO date string "YYYY-MM-DD"
  time:     string;          // "HH:MM"
  name:     string;
  phone:    string;
  email:    string;
  notes:    string;
}

export interface BookingPayload extends BookingFormData {
  telegram_user_id:   number | null;
  telegram_username:  string | null;
  created_at:         string;
}

// ─── Supabase Row ──────────────────────────────────────────────────────────

export interface BookingRow {
  id:                 string;
  service:            ServiceId;
  date:               string;
  time:               string;
  name:               string;
  phone:              string;
  email:              string;
  notes:              string | null;
  telegram_user_id:   number | null;
  telegram_username:  string | null;
  status:             'pending' | 'confirmed' | 'cancelled';
  created_at:         string;
}

// ─── Wizard Steps ──────────────────────────────────────────────────────────

export type Step = 1 | 2 | 3 | 4;

export interface StepMeta {
  number: Step;
  label:  string;
}

// ─── Telegram WebApp ───────────────────────────────────────────────────────

export interface TelegramUser {
  id:         number;
  first_name: string;
  last_name?: string;
  username?:  string;
  photo_url?: string;
}

declare global {
  interface Window {
    Telegram?: {
      WebApp: {
        ready:            () => void;
        expand:           () => void;
        close:            () => void;
        initDataUnsafe:   { user?: TelegramUser };
        MainButton: {
          text:       string;
          show:       () => void;
          hide:       () => void;
          enable:     () => void;
          disable:    () => void;
          showProgress:(leaveActive?: boolean) => void;
          hideProgress:() => void;
          onClick:    (fn: () => void) => void;
          offClick:   (fn: () => void) => void;
          setParams:  (params: { text?: string; color?: string; text_color?: string }) => void;
        };
        BackButton: {
          show:    () => void;
          hide:    () => void;
          onClick: (fn: () => void) => void;
          offClick:(fn: () => void) => void;
        };
        colorScheme:      'light' | 'dark';
        themeParams:      Record<string, string>;
        hapticFeedback: {
          impactOccurred: (style: 'light'|'medium'|'heavy'|'rigid'|'soft') => void;
          notificationOccurred: (type: 'error'|'success'|'warning') => void;
          selectionChanged: () => void;
        };
      };
    };
  }
}
