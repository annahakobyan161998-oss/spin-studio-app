import { Toaster } from 'react-hot-toast'
import { BookingForm } from './components/BookingForm'

export default function App() {
  return (
    <>
      <BookingForm />

      <Toaster
        position="top-center"
        toastOptions={{
          duration: 3000,
          style: {
            background: '#1A1A1A',
            color:      '#F5F5F5',
            border:     '1px solid #2A2A2A',
            fontFamily: '"DM Sans", sans-serif',
            fontSize:   '14px',
            borderRadius: '12px',
          },
          error: {
            iconTheme: { primary: '#C9A84C', secondary: '#0A0A0A' },
          },
          success: {
            iconTheme: { primary: '#C9A84C', secondary: '#0A0A0A' },
          },
        }}
      />
    </>
  )
}
