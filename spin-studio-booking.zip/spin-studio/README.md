# SPiN Studio — Telegram Mini App Booking System

A professional Telegram Mini App for booking studio sessions at **SPiN Studio** (media agency).  
Built with **React + TypeScript + Tailwind CSS**, backed by **Supabase**, deployed on **Vercel**.

---

## ✨ Features

- 4-step booking wizard: Service → Date/Time → Details → Confirmation
- Real-time slot availability (fetched from Supabase on each date selection)
- Telegram WebApp SDK integration: haptic feedback, Back Button, auto-expand, user context
- Dark, premium aesthetic with gold accents — optimized for mobile
- Graceful degradation: works in a regular browser too (for testing)

---

## 🗂 Project Structure

```
spin-studio/
├── public/
├── src/
│   ├── components/
│   │   ├── BookingForm.tsx      ← Main 4-step wizard
│   │   ├── ServiceCard.tsx      ← Service selection card
│   │   ├── StepIndicator.tsx    ← Progress indicator
│   │   ├── SuccessScreen.tsx    ← Post-booking confirmation
│   │   └── LoadingSpinner.tsx   ← Reusable spinner
│   ├── hooks/
│   │   └── useTelegram.ts       ← Telegram WebApp SDK wrapper
│   ├── lib/
│   │   ├── supabase.ts          ← Supabase client + DB helpers
│   │   └── services.ts          ← Service catalogue & time slots
│   ├── types/
│   │   └── index.ts             ← All TypeScript types
│   ├── App.tsx
│   ├── main.tsx
│   └── index.css
├── supabase/
│   └── schema.sql               ← Run in Supabase SQL Editor
├── .env.example                 ← Copy to .env and fill in values
├── vercel.json
├── vite.config.ts
├── tailwind.config.js
└── package.json
```

---

## 🚀 Setup & Deployment

### 1. Clone & install

```bash
git clone https://github.com/YOUR_USERNAME/spin-studio-booking.git
cd spin-studio-booking
npm install
```

### 2. Configure environment

```bash
cp .env.example .env
```

Edit `.env`:

```env
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-key
VITE_APP_URL=https://your-app.vercel.app
```

### 3. Set up Supabase database

1. Create a project at [supabase.com](https://supabase.com)
2. Go to **SQL Editor → New Query**
3. Paste and run the contents of `supabase/schema.sql`
4. Copy your **Project URL** and **anon key** into `.env`

### 4. Run locally

```bash
npm run dev
```

Open `http://localhost:5173` in your browser.

### 5. Deploy to Vercel

```bash
# Push to GitHub first
git add .
git commit -m "Initial commit"
git push origin main

# Then import repo at vercel.com and set env vars:
# VITE_SUPABASE_URL
# VITE_SUPABASE_ANON_KEY
```

### 6. Register as a Telegram Mini App

1. Open [@BotFather](https://t.me/BotFather) in Telegram
2. `/newbot` → create your bot
3. `/newapp` → create a Mini App
4. Set the **Web App URL** to your Vercel deployment URL
5. Share the Mini App link with your clients 🎉

---

## 🛠 Customization

| What to change | Where |
|---|---|
| Services list | `src/lib/services.ts` → `SERVICES` array |
| Time slots | `src/lib/services.ts` → `ALL_TIME_SLOTS` |
| Colors/fonts | `tailwind.config.js` |
| Booking form fields | `src/components/BookingForm.tsx` |
| Success message | `src/components/SuccessScreen.tsx` |

---

## 🔒 Security Notes

- **Never commit `.env`** — it's in `.gitignore`
- Supabase **Row Level Security** is enabled — anonymous users can only insert, not read all bookings
- Add server-side validation (Supabase Edge Functions or a Next.js API route) for production hardening

---

## 📦 Tech Stack

| Layer | Technology |
|---|---|
| Frontend | React 18 + TypeScript |
| Styling | Tailwind CSS v3 |
| Build | Vite 5 |
| Database | Supabase (PostgreSQL) |
| Hosting | Vercel |
| Platform | Telegram Mini Apps SDK |
